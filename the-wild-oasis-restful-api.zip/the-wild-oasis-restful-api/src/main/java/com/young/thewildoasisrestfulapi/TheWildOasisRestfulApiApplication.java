package com.young.thewildoasisrestfulapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TheWildOasisRestfulApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(TheWildOasisRestfulApiApplication.class, args);
	}

}
